"""
EmotionDetection Package.

Provides emotion analysis functionality using IBM Watson NLP services.
"""
from . import emotion_detection